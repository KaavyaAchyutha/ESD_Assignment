class TestArea{
	public static void main(String args[]){
		Shapes s1 = new Shapes();
		Square s2 = new Square();
		Shapes s3 = new Circle();
		Shapes s4 = new Rectangle();
		s1.area();
		int a;
		area = s2.area();
		System.out.println(a);
		System.out.println(s3.area());
		System.out.println(s4.area());
	}
}

